self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "21266a2a921c46233d162e918bc887f9",
    "url": "./index.html"
  },
  {
    "revision": "376eee95170bd9bc4158",
    "url": "./static/css/2.hash.chunk.css"
  },
  {
    "revision": "f43fe11c2b63d4ae1f9b",
    "url": "./static/css/3.hash.chunk.css"
  },
  {
    "revision": "1000766399590e71f498",
    "url": "./static/css/4.hash.chunk.css"
  },
  {
    "revision": "74c1a3328022eaf108a6",
    "url": "./static/css/main.hash.chunk.css"
  },
  {
    "revision": "376eee95170bd9bc4158",
    "url": "./static/js/2.hash.chunk.js"
  },
  {
    "revision": "f43fe11c2b63d4ae1f9b",
    "url": "./static/js/3.hash.chunk.js"
  },
  {
    "revision": "1000766399590e71f498",
    "url": "./static/js/4.hash.chunk.js"
  },
  {
    "revision": "74c1a3328022eaf108a6",
    "url": "./static/js/main.hash.chunk.js"
  },
  {
    "revision": "2bcc722d89d37d980014",
    "url": "./static/js/runtime-main.hash.js"
  },
  {
    "revision": "c91fff83336af5897d91fb4179cc5eff",
    "url": "./static/media/Alice-Regular.c91fff83.ttf"
  },
  {
    "revision": "e64fc9d01f0600a9faf13ce71c15d0ed",
    "url": "./static/media/FontsFree-Net-SF-Pro-Rounded-Bold.e64fc9d0.ttf"
  },
  {
    "revision": "907212050e2a59fbb0aa4cb95b7ca4c0",
    "url": "./static/media/FontsFree-Net-SF-Pro-Rounded-Semibold.90721205.ttf"
  },
  {
    "revision": "3cf0ee273a0b3f022234b6572c3b78f9",
    "url": "./static/media/Gilroy-Bold.3cf0ee27.ttf"
  },
  {
    "revision": "6444f14adcdee041b62184f13139a56d",
    "url": "./static/media/Gilroy-Medium.6444f14a.ttf"
  },
  {
    "revision": "ae5e7255973ffe09b53f07a2805232a8",
    "url": "./static/media/Gilroy-Regular.ae5e7255.ttf"
  },
  {
    "revision": "05bdf30b8aaa10683c19e73dd0c428da",
    "url": "./static/media/Gilroy-SemiBold.05bdf30b.ttf"
  },
  {
    "revision": "95fdabaa78e29ec77e275a5a25e9fd67",
    "url": "./static/media/IconClean.95fdabaa.svg"
  },
  {
    "revision": "546ef30c0fee197a6129d9ce4ea1a64c",
    "url": "./static/media/IconCleanDark.546ef30c.svg"
  },
  {
    "revision": "d6d6db33d4bb966dd4bbfb033f39a38b",
    "url": "./static/media/IconDone.d6d6db33.svg"
  },
  {
    "revision": "ca744edeca92d76b7d790d17290764c5",
    "url": "./static/media/IconDonut.ca744ede.svg"
  },
  {
    "revision": "538657b81818f512ea81da01d1777569",
    "url": "./static/media/IconErase.538657b8.svg"
  },
  {
    "revision": "d1d8758f95d2267809440cf6737f9f94",
    "url": "./static/media/IconErase2.d1d8758f.svg"
  },
  {
    "revision": "bd03b526b9f376808a7434e493edfd0f",
    "url": "./static/media/IconErase2_20.bd03b526.svg"
  },
  {
    "revision": "bf4910b8fd5474584d76ae81310d7b87",
    "url": "./static/media/IconErrorClean.bf4910b8.svg"
  },
  {
    "revision": "5a6d058959c4a430648263cbbd7a061d",
    "url": "./static/media/IconStroke.5a6d0589.svg"
  },
  {
    "revision": "5ff1f2a9a78730d7d0c309320ff3c9c7",
    "url": "./static/media/Inter-Medium.5ff1f2a9.ttf"
  },
  {
    "revision": "515cae74eee4925d56e6ac70c25fc0f6",
    "url": "./static/media/Inter-Regular.515cae74.ttf"
  },
  {
    "revision": "ec60b23f3405050f546f4765a9e90fec",
    "url": "./static/media/Inter-SemiBold.ec60b23f.ttf"
  },
  {
    "revision": "850ffaa2af959cbc68e9f8ab6ccbf4db",
    "url": "./static/media/Manrope-Bold.850ffaa2.ttf"
  },
  {
    "revision": "6b0f2123870ccd0cfbb6edd650ff6f22",
    "url": "./static/media/Manrope-ExtraBold.6b0f2123.ttf"
  },
  {
    "revision": "f661a8056d8cbfa46500658db3ccb646",
    "url": "./static/media/Manrope-Medium.f661a805.ttf"
  },
  {
    "revision": "2640802b08e8f37e557305e1c116ccd4",
    "url": "./static/media/Manrope.2640802b.ttf"
  },
  {
    "revision": "ee6539921d713482b8ccd4d0d23961bb",
    "url": "./static/media/Montserrat-Regular.ee653992.ttf"
  },
  {
    "revision": "c641dbee1d75892e4d88bdc31560c91b",
    "url": "./static/media/Montserrat-SemiBold.c641dbee.ttf"
  },
  {
    "revision": "2b93e8e975cd6d488fe0e635541728f9",
    "url": "./static/media/ProximaNova-Bold.2b93e8e9.ttf"
  },
  {
    "revision": "1fc524a22c99e8d63393ecfe238e3d35",
    "url": "./static/media/ProximaNova-Regular.1fc524a2.ttf"
  },
  {
    "revision": "3625e925425cb102cadb2f5db79c9aa0",
    "url": "./static/media/ProximaNova-Semibold.3625e925.ttf"
  },
  {
    "revision": "11eabca2251325cfc5589c9c6fb57b46",
    "url": "./static/media/Roboto-Regular.11eabca2.ttf"
  },
  {
    "revision": "644563f48ab5fe8e9082b64b2729b068",
    "url": "./static/media/SF-Pro-Display-Bold.644563f4.otf"
  },
  {
    "revision": "a545fc03ce079844a5ff898a25fe589b",
    "url": "./static/media/SF-Pro-Display-Heavy.a545fc03.otf"
  },
  {
    "revision": "51fd7406327f2b1dbc8e708e6a9da9a5",
    "url": "./static/media/SF-Pro-Display-Medium.51fd7406.otf"
  },
  {
    "revision": "aaeac71d99a345145a126a8c9dd2615f",
    "url": "./static/media/SF-Pro-Display-Regular.aaeac71d.otf"
  },
  {
    "revision": "e6ef4ea3cf5b1b533a85a5591534e3e4",
    "url": "./static/media/SF-Pro-Display-Semibold.e6ef4ea3.otf"
  },
  {
    "revision": "400bd9f855cefe6a13b02eb55a31d511",
    "url": "./static/media/SF-Pro-Rounded-Regular.400bd9f8.ttf"
  },
  {
    "revision": "5b6c7cdfe0acd0fcc93cef7984a08740",
    "url": "./static/media/SF-Pro-Text-Bold.5b6c7cdf.otf"
  },
  {
    "revision": "d7829d9b3a4514b125d758dcace0613b",
    "url": "./static/media/SF-Pro-Text-Heavy.d7829d9b.otf"
  },
  {
    "revision": "9491854a8b6ec3a0c915668083f18fde",
    "url": "./static/media/SF-Pro-Text-Medium.9491854a.otf"
  },
  {
    "revision": "85bd46c1cff02c1d8360cc714b8298fa",
    "url": "./static/media/SF-Pro-Text-Regular.85bd46c1.ttf"
  },
  {
    "revision": "8f079b59ff6659b39b41bc2255c968b8",
    "url": "./static/media/SF-Pro-Text-Semibold.8f079b59.otf"
  },
  {
    "revision": "d4550c5e326a628ac8ef82e9f2703484",
    "url": "./static/media/SFUIDisplay-Regular.d4550c5e.otf"
  },
  {
    "revision": "888e0f3f1d925d57beaf9cc4a7b80dbc",
    "url": "./static/media/SFUIText-Regular.888e0f3f.otf"
  },
  {
    "revision": "c17139226e8bdce535a4c5c98ded65e7",
    "url": "./static/media/Story1.c1713922.png"
  },
  {
    "revision": "28d56ba982421c612123bf272f97f529",
    "url": "./static/media/Story2.28d56ba9.png"
  },
  {
    "revision": "2f47cccba81c84eddde5e14ce4c51a08",
    "url": "./static/media/Story3.2f47cccb.png"
  },
  {
    "revision": "c7c4799ed1182d24a48397cf98074b7f",
    "url": "./static/media/Stupid-Head.c7c4799e.ttf"
  },
  {
    "revision": "03428f670a1439505c4e1bce5a0b2d18",
    "url": "./static/media/TTCommons-Bold.03428f67.ttf"
  },
  {
    "revision": "2e6a293a70716ab24d1af2f7de14b226",
    "url": "./static/media/TTCommons-DemiBold.2e6a293a.ttf"
  },
  {
    "revision": "fc6fbc1addf37a7f957715e41b20291d",
    "url": "./static/media/TTCommons-Regular.fc6fbc1a.ttf"
  },
  {
    "revision": "44097099334ab7be3261ff85409a62fc",
    "url": "./static/media/TTFirsNeue-DemiBold.44097099.ttf"
  },
  {
    "revision": "df13f74fd7ca2b2797d475e6a4c66cc2",
    "url": "./static/media/TTFirsNeue-Medium.df13f74f.ttf"
  },
  {
    "revision": "0de1b0e6c40db0a73c06348a08ea2b4f",
    "url": "./static/media/TTFirsNeue-Regular.0de1b0e6.ttf"
  },
  {
    "revision": "d9521fb6878e132c215281e9494e232a",
    "url": "./static/media/WC-Mano-Negra-Bta.d9521fb6.otf"
  },
  {
    "revision": "1c0cb9cc68927ea3bb64faafcf196e0b",
    "url": "./static/media/cancel-14.1c0cb9cc.svg"
  },
  {
    "revision": "a6a5abf89d84f607af7b48334c4ce744",
    "url": "./static/media/check-14.a6a5abf8.svg"
  },
  {
    "revision": "03dea953a5a5829841352d649ebf79fe",
    "url": "./static/media/star-14.03dea953.svg"
  },
  {
    "revision": "f793eab7243d552ed72248601b4824ee",
    "url": "./static/media/zap.f793eab7.svg"
  }
]);